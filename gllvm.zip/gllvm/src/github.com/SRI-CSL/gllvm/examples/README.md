# Examples of using GLLVM


A simple set of instructions for building apache in a vagrant Ubuntu 14.04 can be found
[here,](tutorial.md) and for Ubuntu 16.04 [here.](tutorial-ubuntu-16.04.md)

The big example here though is the [linux kernel.](linux-kernel)

