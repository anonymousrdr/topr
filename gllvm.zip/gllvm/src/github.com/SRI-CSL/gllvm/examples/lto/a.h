//https://llvm.org/docs/LinkTimeOptimization.html
extern int foo1(void);
extern void foo2(void);
extern void foo4(void);
