#include <stdio.h>
int main(void) {
    printf("test\n");
}
