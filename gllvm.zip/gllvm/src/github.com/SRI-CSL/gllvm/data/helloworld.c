#include <stdio.h>


int main(int argc, char *argv[]) {

  fprintf(stdout, "hello world");

}
